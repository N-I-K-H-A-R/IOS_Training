import Foundation

class MyConstants {
    
    static func getDisneyCharactersList() -> URL {
        return URL(string : "https://api.disneyapi.dev/characters")!
    }
}


