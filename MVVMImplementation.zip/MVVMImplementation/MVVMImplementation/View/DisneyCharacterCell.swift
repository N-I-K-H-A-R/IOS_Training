
import UIKit

class DisneyCharacetrCell: UITableViewCell {
    
    @IBOutlet weak var characterImage: UIImageView!
    @IBOutlet weak var characterName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.characterImage.layer.cornerRadius = self.characterImage.frame.size.height / 2
        self.characterImage.layer.masksToBounds = true
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    var disneyCharacter: Datum? {
        didSet {
            self.characterName.text = disneyCharacter?.name
            self.characterImage.loadThumbnail(urlSting: disneyCharacter!.imageURL)
        }
    }
}
