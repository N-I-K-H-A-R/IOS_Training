import UIKit

class DashboardVC: UIViewController {
    var disneyCharactersViewModal = DisneyCharactersViewModal()
    @IBOutlet weak var myTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Disney Characters List"
        self.navigationController?.navigationBar.titleTextAttributes = [ .foregroundColor: UIColor.white,
            .font: UIFont.systemFont(ofSize: 20.0) ]
        self.myTableView.register(UINib(nibName: "DisneyCharacterCell", bundle: nil),
                                  forCellReuseIdentifier: "DisneyCharacterCell")
        getDisneyCharactersList()
    }
    func getDisneyCharactersList() {
        disneyCharactersViewModal.timeToReloadTable = { [weak self] in
            DispatchQueue.main.async {
                self?.myTableView.reloadData()
            }
        }
        disneyCharactersViewModal.fetchDisneyCharactersListFromServer()
    }
}

extension DashboardVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: DisneyCharacetrCell = tableView.dequeueReusableCell(withIdentifier: "DisneyCharacterCell",
                                                                      for: indexPath) as! DisneyCharacetrCell
        cell.disneyCharacter = disneyCharactersViewModal.disneyCharacterListData?.data[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return disneyCharactersViewModal.disneyCharacterListData?.count ?? 0
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailsVC = DetailsVC()
        detailsVC.disneyCharacterData = disneyCharactersViewModal.disneyCharacterListData?.data[indexPath.row]
        self.navigationController?.pushViewController(detailsVC, animated: true)
    }
}
