import UIKit

class DetailsVC: UIViewController {
    @IBOutlet weak var characterNameLabel: UILabel!
    @IBOutlet weak var filmsLabel: UILabel!
    @IBOutlet weak var shortFilmsLabel: UILabel!
    @IBOutlet weak var tvShowsLabel: UILabel!
    @IBOutlet weak var videoGamesLabel: UILabel!
    @IBOutlet weak var parkAttractionsLabel: UILabel!
    var disneyCharacterData: Datum?
    @IBOutlet weak var characterImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setVCProperties()
    }
    func setVCProperties() {
        self.characterImage.loadThumbnail(urlSting: disneyCharacterData?.imageURL ?? "link to a placeholder image")
        self.characterNameLabel.text = disneyCharacterData?.name
        if disneyCharacterData?.films.isEmpty == false {
            self.filmsLabel.text = disneyCharacterData?.films[0]
        }
        if disneyCharacterData?.shortFilms.isEmpty == false {
            self.shortFilmsLabel.text = disneyCharacterData?.shortFilms[0]
        }
        if disneyCharacterData?.tvShows.isEmpty == false {
            self.tvShowsLabel.text = disneyCharacterData?.tvShows[0]
        }
        if disneyCharacterData?.videoGames.isEmpty == false {
            self.videoGamesLabel.text = disneyCharacterData?.videoGames[0]
        }
        if disneyCharacterData?.parkAttractions.isEmpty == false {
            self.parkAttractionsLabel.text = disneyCharacterData?.parkAttractions[0]
        }
    }
}
