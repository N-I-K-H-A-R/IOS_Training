
import UIKit


class HomePageVC: UIViewController {
    
    var disneyCharactersViewModal = DisneyCharactersViewModal()
    var disneyCharactersData: DisneyCharacter?
    var index = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getDisneyCharactersList()
    }
    
    func getDisneyCharactersList() {
        
        // Show activity Indicator
//        let activityIndicatorView = UIActivityIndicatorView(style: .medium)
//        self.view.addSubview(activityIndicatorView)
//        activityIndicatorView.startAnimating()
        let indicatorView = self.activityIndicator(style: .medium, center: self.view.center)
        self.view.addSubview(indicatorView)
        indicatorView.startAnimating()
        
        disneyCharactersViewModal.timeToReloadTable = { [weak self] in
            DispatchQueue.main.async {
                
                // Hide activity Indicator
                indicatorView.stopAnimating()
            }
        }
        disneyCharactersViewModal.fetchDisneyCharactersListFromServer()
    }
    
    @IBAction func disneyWorldButton(_ sender: UIButton) {
        let dashBoardVC = DashboardVC()
        self.navigationController?.pushViewController(dashBoardVC, animated: true)
    }
    
    @IBAction func popularSearchesPressed(_ sender: UIButton) {
        let detailsVC = DetailsVC()

        switch sender.titleLabel?.text {
        case "Ace":
            index = 22
        case "A.R.F.":
            index = 7
        case "Aggro":
            index = 49
        case "Aerosol":
            index = 42
        case "Adam Gator":
            index = 28
        case "Agent K":
            index = 46
        default:
            index = 0
        }
        
        detailsVC.disneyCharacterData = disneyCharactersViewModal.disneyCharacterListData?.data[index]
        self.navigationController?.pushViewController(detailsVC, animated: true)
    }
    
    
    
    
    private func activityIndicator(style: UIActivityIndicatorView.Style = .medium,
                                   frame: CGRect? = nil,
                                   center: CGPoint? = nil) -> UIActivityIndicatorView {
        
        let activityIndicatorView = UIActivityIndicatorView(style: style)
        
        if let frame = frame {
            activityIndicatorView.frame = frame
        }
        
        if let center = center {
            activityIndicatorView.center = center
        }

        return activityIndicatorView
    }
    
}
