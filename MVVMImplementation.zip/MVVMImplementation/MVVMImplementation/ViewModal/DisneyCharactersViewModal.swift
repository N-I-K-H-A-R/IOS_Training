import Foundation

class DisneyCharactersViewModal {
    init() {
    }
    private let networkManager = NetworkingManager.shared
    var timeToReloadTable: (() -> Void)?
    var disneyCharacterListData: DisneyCharacter? {
        didSet {
            self.timeToReloadTable?()
        }
    }
    func fetchDisneyCharactersListFromServer() {
        networkManager.getData(url: MyConstants.getDisneyCharactersList(), objectType: DisneyCharacter.self) {data in
            switch data {
            case .success(let myData):
                self.disneyCharacterListData = myData
            case .failure(let error):
                print(error)
            }
        }
    }
}
